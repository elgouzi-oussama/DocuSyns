<?php $__env->startSection('title', __('contact.title') . ' | DocuSyns'); ?>
<?php $__env->startSection('page_title', __('contact.page_title')); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white p-6 mt-5 rounded-lg shadow-sm w-[90%] mx-auto">
    <h1 class="text-2xl font-bold mb-4">📬 <?php echo e(__('contact.heading')); ?></h1>
    <p class="text-gray-600 mb-6"><?php echo e(__('contact.subtitle')); ?></p>

    <?php if(session('success')): ?>
    <div class="mb-4 bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('user.contact.send')); ?>" class="space-y-4 ">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block text-gray-700 mb-1"><?php echo e(__('contact.subject')); ?></label>
            <input type="text" name="subject" value="<?php echo e(old('subject')); ?>"
                class="w-full bg-gray-300 border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500">
            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label class="block text-gray-700 mb-1"><?php echo e(__('contact.message')); ?></label>
            <textarea name="message" rows="5"
                class="w-full bg-gray-300 border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500"><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="text-right">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                <?php echo e(__('contact.send_button')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\contact\index.blade.php ENDPATH**/ ?>