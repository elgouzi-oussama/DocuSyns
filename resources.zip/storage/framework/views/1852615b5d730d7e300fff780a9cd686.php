<?php $__env->startSection('title', __('invoice.confirm.page_title')); ?>
<?php $__env->startSection('page_title', __('invoice.confirm.page_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="mb-4 p-3 text-green-800 bg-green-100 rounded-lg">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="bg-white shadow-lg rounded-2xl p-8 w-full max-w-5xl">
    <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center select-none">
        <?php echo e(__('invoice.confirm.heading')); ?>

    </h1>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <form action="<?php echo e(route('admin.invoices.confirm')); ?>" method="POST" class="space-y-5">
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
        <form action="<?php echo e(route('super_admin.invoices.confirm')); ?>" method="POST" class="space-y-5">
            <?php endif; ?>
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                
                <?php if(!empty($allData['reference_commande'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.reference')); ?>

                    </label>
                    <input type="text" name="reference_commande"
                        value="<?php echo e($allData['reference_commande']); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.reference_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['date_commande'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.date')); ?>

                    </label>
                    <input type="date" name="date_commande"
                        value="<?php echo e(\Carbon\Carbon::parse($allData['date_commande'])->format('Y-m-d')); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.date_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['nom_fournisseur'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.supplier')); ?>

                    </label>
                    <input type="text" name="nom_fournisseur"
                        value="<?php echo e($allData['nom_fournisseur']); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.supplier_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['code_fournisseur'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.supplier_code')); ?>

                    </label>
                    <input type="text" name="code_fournisseur"
                        value="<?php echo e($allData['code_fournisseur']); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.supplier_code_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['commande_par'])): ?>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.ordered_by')); ?>

                    </label>
                    <textarea name="commande_par" rows="2"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500"><?php echo e($allData['commande_par']); ?></textarea>
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg md:col-span-2 select-none">
                    <?php echo e(__('invoice.confirm.errors.commanded_by_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['commande_a'])): ?>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none">
                        <?php echo e(__('invoice.confirm.ordered_to')); ?>

                    </label>
                    <textarea name="commande_a" rows="2"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500"><?php echo e($allData['commande_a']); ?></textarea>
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg md:col-span-2 select-none">
                    <?php echo e(__('invoice.confirm.errors.commanded_to_missing')); ?>

                </div>
                <?php endif; ?>

                
                
                <?php if(!empty($allData['montant_ht'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none"><?php echo e(__('invoice.confirm.amount_ht')); ?></label>
                    <input type="text" name="montant_ht"
                        value="<?php echo e(number_format((float)$allData['montant_ht'], 2, ',', ' ')); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.montant_ht_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['montant_tva'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1" select-none><?php echo e(__('invoice.confirm.amount_tva')); ?></label>
                    <input type="text" name="montant_tva"
                        value="<?php echo e(number_format((float)$allData['montant_tva'], 2, ',', ' ')); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.montant_tva_missing')); ?>

                </div>
                <?php endif; ?>

                
                <?php if(!empty($allData['montant_ttc'])): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1 select-none"> <?php echo e(__('invoice.confirm.amount_ttc')); ?></label>
                    <input type="text" name="montant_ttc"
                        value="<?php echo e(number_format((float)$allData['montant_ttc'], 2, ',', ' ')); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500">
                </div>
                <?php else: ?>
                <div class="text-red-600 bg-red-50 p-3 rounded-lg select-none">
                    <?php echo e(__('invoice.confirm.errors.montant_ttc_missing')); ?>

                </div>
                <?php endif; ?>

                <input type="hidden" name="file" value="<?php echo e($allData['file']); ?>">
                <input type="hidden" name="user_id" value="<?php echo e($allData['user_id']); ?>">
                <input type="hidden" name="statut" value="<?php echo e($allData['statut']); ?>">
                <input type="hidden" name="articles" value='<?php echo json_encode($allData["items"], 15, 512) ?>'>
            </div>

            <div class="p-0">
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm text-left border-collapse">
                        <thead class="bg-gray-800 text-white">
                            <tr>
                                <?php $__currentLoopData = array_keys($allData['items'][0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-4 py-3">
                                    <?php echo e($key); ?>

                                </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <?php $__empty_1 = true; $__currentLoopData = $allData['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50">
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-4 py-2 text-center">
                                    <?php echo e($value); ?>

                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="px-4 py-6 text-center text-gray-500 italic">
                                    Aucun article trouvé
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>


                    </table>
                </div>
            </div>


            <div class="pt-6 flex justify-between">
                <a href="<?php echo e(route('invoice.create')); ?>"
                    class="px-6 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition">
                    <?php echo e(__('invoice.confirm.buttons.back')); ?>

                </a>
                <button type="submit"
                    class="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition select-none">
                    <?php echo e(__('invoice.confirm.buttons.confirm_save')); ?>

                </button>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\invoices\see.blade.php ENDPATH**/ ?>