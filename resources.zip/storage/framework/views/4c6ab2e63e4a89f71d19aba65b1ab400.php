<?php $__env->startSection('title', __('user.show.title')); ?>
<?php $__env->startSection('page_title', __('user.show.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">
    <?php if(session('success')): ?>
    <div class="mb-4 bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <h2 class="text-lg font-semibold text-gray-700 mb-4"><?php echo e($user->name); ?></h2>

    <p><strong><?php echo e(__('user.show.email')); ?> :</strong> <?php echo e($user->email); ?></p>
    <p><strong><?php echo e(__('user.show.role')); ?> :</strong> <?php echo e(ucfirst($user->role ?? 'user')); ?></p>
    <p><strong><?php echo e(__('user.show.created_at')); ?> :</strong> <?php echo e($user->created_at->format('d/m/Y H:i')); ?></p>
    <p><strong><?php echo e(__('user.show.updated_at')); ?> :</strong> <?php echo e($user->updated_at->format('d/m/Y H:i')); ?></p>

    <div class="mt-4 flex justify-end space-x-3">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
        <a href="<?php echo e(route('super_admin.users.edit', $user)); ?>" class="bg-yellow-500 text-white px-3 py-2 rounded">
            <?php echo e(__('user.show.edit')); ?>

        </a>
        <a href="<?php echo e(route('super_admin.users.index')); ?>" class="bg-gray-300 mx-3 px-3 py-2 rounded">
            <?php echo e(__('user.show.back')); ?>

        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isSuperAdmin')): ?>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-gray-300 mx-3 px-3 py-2 rounded">
            <?php echo e(__('user.show.back')); ?>

        </a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\users\show.blade.php ENDPATH**/ ?>