<?php $__env->startSection('title', __('invoice.editt.page_title')); ?>
<?php $__env->startSection('page_title', __('invoice.editt.heading')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <form method="POST" action="<?php echo e(route('admin.invoices.update', $invoice->id)); ?>">
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
        <form method="POST" action="<?php echo e(route('super_admin.invoices.update', $invoice->id)); ?>">
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.user')); ?></label>
                <select name="user_id" class="w-full border-gray-300 rounded px-3 py-2 bg-gray-200" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e($invoice->user_id == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.reference')); ?></label>
                    <input type="text" name="reference_commande"
                        value="<?php echo e(old('reference_commande', $invoice->reference_commande)); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['reference_commande'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.date')); ?></label>
                    <input type="date" name="date_commande"
                        value="<?php echo e(old('date_commande', \Carbon\Carbon::parse($invoice->date_commande)->format('Y-m-d'))); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['date_commande'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.supplier')); ?></label>
                    <input type="text" name="nom_fournisseur"
                        value="<?php echo e(old('nom_fournisseur', $invoice->nom_fournisseur)); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['nom_fournisseur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.supplier_code')); ?></label>
                    <input type="text" name="code_fournisseur"
                        value="<?php echo e(old('code_fournisseur', $invoice->code_fournisseur)); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['code_fournisseur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.ordered_by')); ?></label>
                    <textarea name="commande_par" rows="2"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"><?php echo e(old('commande_par', $invoice->commande_par)); ?></textarea>
                    <?php $__errorArgs = ['commande_par'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.ordered_to')); ?></label>
                    <textarea name="commande_a" rows="2"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"><?php echo e(old('commande_a', $invoice->commande_a)); ?></textarea>
                    <?php $__errorArgs = ['commande_a'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.amount_ht')); ?> (DH)</label>
                    <input type="text" name="montant_ht"
                        value="<?php echo e(old('montant_ht', number_format((float)$invoice->montant_ht, 2, ',', ' '))); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['montant_ht'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.amount_tva')); ?> (DH)</label>
                    <input type="text" name="montant_tva"
                        value="<?php echo e(old('montant_tva', number_format((float)$invoice->montant_tva, 2, ',', ' '))); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['montant_tva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.amount_ttc')); ?> (DH)</label>
                    <input type="text" name="montant_ttc"
                        value="<?php echo e(old('montant_ttc', number_format((float)$invoice->montant_ttc, 2, ',', ' '))); ?>"
                        class="bg-gray-200 p-2 w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php $__errorArgs = ['montant_ttc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="mb-4 mt-4">
                <label class="block text-sm font-medium text-gray-700 mb-1"><?php echo e(__('invoice.editt.status')); ?></label>
                <select name="statut" class="w-full border-gray-300 rounded px-3 py-2 bg-gray-200">
                    <option value="en_attente" <?php echo e($invoice->status == 'en_attente' ? 'selected' : ''); ?>>
                        <?php echo e(__('invoice.status.pending')); ?>

                    </option>
                    <option value="approuvé" <?php echo e($invoice->status == 'approuvé' ? 'selected' : ''); ?>>
                        <?php echo e(__('invoice.status.approved')); ?>

                    </option>
                    <option value="rejeté" <?php echo e($invoice->status == 'rejeté' ? 'selected' : ''); ?>>
                        <?php echo e(__('invoice.status.rejected')); ?>

                    </option>
                </select>
                <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="flex justify-end space-x-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <a href="<?php echo e(route('admin.invoices.index')); ?>" class="px-4 py-2 bg-gray-300 rounded">
                    <?php echo e(__('invoice.editt.cancel')); ?>

                </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
                <a href="<?php echo e(route('super_admin.invoices.index')); ?>" class="px-4 py-2 bg-gray-300 rounded mx-2">
                    <?php echo e(__('invoice.editt.cancel')); ?>

                </a>
                <?php endif; ?>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
                    <?php echo e(__('invoice.editt.update')); ?>

                </button>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\invoices\edit.blade.php ENDPATH**/ ?>