<?php $__env->startSection('title', __('admin.profile_edit.title')); ?>
<?php $__env->startSection('page_title', __('admin.profile_edit.page_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 border border-green-300 rounded-lg px-4 py-3">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">
    <h3 class="text-lg font-semibold mb-4"><?php echo e(__('admin.profile_edit.subtitle')); ?></h3>

    <form action="<?php echo e(route('super_admin.profile.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-gray-700 text-sm mb-1"><?php echo e(__('admin.profile_edit.name')); ?></label>
            <input type="text" name="name" value="<?php echo e(old('name', $admin->name)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 text-sm mb-1"><?php echo e(__('admin.profile_edit.email')); ?></label>
            <input type="email" name="email" value="<?php echo e(old('email', $admin->email)); ?>"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 text-sm mb-1"><?php echo e(__('admin.profile_edit.new_password')); ?></label>
            <input type="password" name="password"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 text-sm mb-1"><?php echo e(__('admin.profile_edit.confirm_password')); ?></label>
            <input type="password" name="password_confirmation"
                class="w-full border border-gray-300 rounded px-3 py-2 focus:ring focus:ring-blue-200">
        </div>

        <div class="flex justify-between">
            <a href="<?php echo e(route('super_admin.dashboard')); ?>" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">
                <?php echo e(__('admin.profile_edit.back')); ?>

            </a>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                <?php echo e(__('admin.profile_edit.save')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\profile\edit.blade.php ENDPATH**/ ?>