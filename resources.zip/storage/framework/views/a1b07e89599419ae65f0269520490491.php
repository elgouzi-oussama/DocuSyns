    

    <?php $__env->startSection('title', __('invoice.page_title') . ' | DocuSyns'); ?>
    <?php $__env->startSection('page_title', __('invoice.page_title') . ' | DocuSyns'); ?>

    <?php $__env->startSection('content'); ?>
    <div class="p-6 flex justify-content-between align-items-center">
        <h1 class="text-3xl m-4 font-bold mb-6 text-gray-800">📄 <?php echo e(__('invoice.heading')); ?></h1>

        
        <?php if(session('success')): ?>
        <div class="w-50 h-12 m-4 rounded-lg bg-green-100 border border-green-300 text-green-800 px-4 py-3">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="mb-4 rounded-lg bg-red-100 border border-red-300 text-red-800 px-4 py-3">
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="flex-1 flex flex-col items-center justify-center text-center w-full">

        
        <div class="flex space-x-3 mb-6">
            <a href="<?php echo e(route('index')); ?>"
                class="bg-gray-500 hover:bg-gray-700 text-white px-5 py-2 rounded-lg shadow">
                <?php echo e(__('invoice.back')); ?>

            </a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.create')): ?>
            <a href="<?php echo e(route('invoice.create')); ?>"
                class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow">
                <?php echo e(__('invoice.add_auto')); ?>

            </a>
            <?php endif; ?>
        </div>

        
        <div class="bg-white shadow-md rounded-lg overflow-hidden w-full max-w-5xl">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <?php echo e(__('invoice.reference')); ?>

                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <?php echo e(__('invoice.supplier')); ?>

                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <?php echo e(__('invoice.date')); ?>

                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <?php echo e(__('invoice.amount_ttc')); ?>

                        </th>
                        <th class="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <?php echo e(__('invoice.actions')); ?>

                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($invoice->reference_commande); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($invoice->nom_fournisseur); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700"><?php echo e($invoice->date_commande); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-700">
                            <?php if(app()->getLocale() === 'ar'): ?>
                            <span dir="ltr">
                                <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?>&lrm;</span>
                            <span><?php echo e(__('admin.currency')); ?></span>
                            <?php else: ?>
                            <span dir="ltr">
                                <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?></span>
                            <span><?php echo e(__('admin.currency')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-right space-x-3 ">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.show')): ?>
                            <a href="<?php echo e(route('invoice.show', $invoice->id)); ?>"
                                class="text-blue-600 hover:text-blue-800  font-semibold"><?php echo e(__('invoice.view')); ?></a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.edit')): ?>
                            <a href="<?php echo e(route('invoice.edit', $invoice->id)); ?>"
                                class="text-yellow-600 hover:text-yellow-800  font-semibold"><?php echo e(__('invoice.edit')); ?></a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.delete')): ?>
                            <form action="<?php echo e(route('invoice.destroy', $invoice->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    onclick="return confirm('<?php echo e(__('invoice.delete_confirm')); ?>')"
                                    class="text-red-600 hover:text-red-800 font-semibold">
                                    <?php echo e(__('invoice.delete')); ?>

                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            <?php echo e(__('invoice.no_invoice')); ?>

                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\invoice\index.blade.php ENDPATH**/ ?>