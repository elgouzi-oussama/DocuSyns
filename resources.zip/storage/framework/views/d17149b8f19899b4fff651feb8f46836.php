<?php $__env->startSection('title', __('admin.profile.title')); ?>
<?php $__env->startSection('page_title', __('admin.profile.page_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="mb-4 bg-green-100 text-green-800 border border-green-300 rounded-lg px-4 py-3">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">
    <div class="mb-6">
        <h2 class="text-xl font-semibold mb-2"><?php echo e(__('admin.profile.account_info')); ?></h2>
        <p><strong><?php echo e(__('admin.profile.name')); ?> :</strong> <?php echo e($admin->name); ?></p>
        <p><strong><?php echo e(__('admin.profile.email')); ?> :</strong> <?php echo e($admin->email); ?></p>
        <p><strong><?php echo e(__('admin.profile.role')); ?> :</strong> <?php echo e(ucfirst($admin->role)); ?></p>
        <p><strong><?php echo e(__('admin.profile.created_at')); ?> :</strong> <?php echo e($admin->created_at->format('d/m/Y H:i')); ?></p>
        <p><strong><?php echo e(__('admin.profile.updated_at')); ?> :</strong> <?php echo e($admin->updated_at->format('d/m/Y H:i')); ?></p>
    </div>

    <div class="flex justify-between">
        <a href="<?php echo e(route('super_admin.dashboard')); ?>" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">
            <?php echo e(__('admin.profile.back')); ?>

        </a>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
        <a href="<?php echo e(route('super_admin.profile.edit')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            <?php echo e(__('admin.profile.edit')); ?>

        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile.edit')): ?>
        <a href="<?php echo e(route('super_admin.profile.edit')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            <?php echo e(__('admin.profile.edit')); ?>

        </a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\profile\show.blade.php ENDPATH**/ ?>