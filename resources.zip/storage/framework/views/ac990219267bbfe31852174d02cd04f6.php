<?php $__env->startSection('title', __('invoice.show.title', ['id' => $invoice->id])); ?>
<?php $__env->startSection('page_title', __('invoice.show.page_title', ['id' => $invoice->id])); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-5xl mx-auto <?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">

    <?php if(session('success')): ?>
    <div class="mb-4 bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <h2 class="text-xl font-semibold mb-4 text-gray-700">
        <?php echo e(__('invoice.show.heading', ['id' => $invoice->id])); ?>

    </h2>

    <div class="space-y-3">
        <div class="p-6 bg-white rounded-lg shadow-md space-y-2 text-gray-800">
            <h2 class="text-xl font-semibold mb-4"><?php echo e(__('invoice.show.details_title')); ?></h2>

            <p><strong><?php echo e(__('invoice.show.fields.user')); ?>:</strong> <?php echo e($invoice->user->name ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.email')); ?>:</strong> <?php echo e($invoice->user->email ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.reference')); ?>:</strong> <?php echo e($invoice->reference_commande ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.date')); ?>:</strong>
                <?php echo e($invoice->date_commande ? \Carbon\Carbon::parse($invoice->date_commande)->format('d/m/Y') : '—'); ?>

            </p>
            <p><strong><?php echo e(__('invoice.show.fields.supplier_name')); ?>:</strong> <?php echo e($invoice->nom_fournisseur ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.supplier_code')); ?>:</strong> <?php echo e($invoice->code_fournisseur ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.ordered_by')); ?>:</strong> <?php echo e($invoice->commande_par ?? '—'); ?></p>
            <p><strong><?php echo e(__('invoice.show.fields.ordered_to')); ?>:</strong> <?php echo e($invoice->commande_a ?? '—'); ?></p>

            <p><strong><?php echo e(__('invoice.show.fields.amount_ht')); ?>:</strong>
                <?php if(app()->getLocale() === 'ar'): ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_ht, 2, ',', ' ')); ?>&lrm;</span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php else: ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_ht, 2, ',', ' ')); ?></span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php endif; ?>
            </p>
            <p><strong><?php echo e(__('invoice.show.fields.amount_tva')); ?>:</strong>
                <?php if(app()->getLocale() === 'ar'): ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_tva, 2, ',', ' ')); ?>&lrm;</span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php else: ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_tva, 2, ',', ' ')); ?></span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php endif; ?>
            </p>
            <p><strong><?php echo e(__('invoice.show.fields.amount_ttc')); ?>:</strong>
                <?php if(app()->getLocale() === 'ar'): ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?>&lrm;</span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php else: ?>
                <span dir="ltr">
                    <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?></span>
                <span><?php echo e(__('admin.currency')); ?></span>
                <?php endif; ?>
            </p>

            <p><strong><?php echo e(__('invoice.show.fields.status')); ?>:</strong>
                <span class="px-2 py-1 rounded text-sm
                    <?php if($invoice->statut === 'approuvé'): ?> bg-green-100 text-green-700
                    <?php elseif($invoice->statut === 'rejeté'): ?> bg-red-100 text-red-700
                    <?php else: ?> bg-yellow-100 text-yellow-700 
                    <?php endif; ?>
                    ">
                    <?php echo e(__('invoice.show.status.' . $invoice->statut)); ?>

                </span>
            </p>

            <p><strong><?php echo e(__('invoice.show.fields.created_at')); ?>:</strong> <?php echo e($invoice->created_at->format('d/m/Y H:i')); ?></p>

            <?php if($invoice->file): ?>
            <p><strong><?php echo e(__('invoice.show.fields.file')); ?>:</strong>
                <a href="<?php echo e(asset('storage/' . $invoice->file)); ?>" target="_blank" class="text-blue-600 hover:underline">
                    📎 <?php echo e(__('invoice.show.view_file')); ?>

                </a>
            </p>
            <?php endif; ?>
            




        </div>


        <?php if($invoice->articles): ?>
        <div class="mt-6 text-start  ">
            <!-- <button id="show-articles"
                    class="bg-gray-300 text-black px-3 p-2 hover:bg-gray-700 hover:text-white  rounded-lg">
                    📄 Voir les articles
                </button> -->
        </div>


        <div>
            <h2 class="text-xl font-bold mb-4">Articles</h2>

            <table class="min-w-full border border-gray-300 text-sm">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <?php $__currentLoopData = array_keys($invoice->articles[0] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-3 py-2 border-b"><?php echo e($key); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoice->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-3 py-2 border-b"><?php echo e($value); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- <div class="text-right mt-4">
                    <button id="close-modal" class="bg-gray-600 text-white px-4 py-2 rounded-lg">Fermer</button>
                </div> -->
        </div>
        <?php endif; ?>


        


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <div class="flex justify-between space-x-3 mt-6">
            <div class="flex justify-start">
                <?php if($invoice->statut !== 'approuvé'): ?>
                <form action="<?php echo e(route('admin.invoices.approve', $invoice->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="bg-green-600 text-white px-4 py-2 rounded"> <?php echo e(__('invoice.show.actions.approve')); ?></button>
                </form>
                <?php elseif($invoice->statut !== 'rejeté'): ?>
                <form action="<?php echo e(route('admin.invoices.reject', $invoice->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="bg-red-600 text-white px-4 py-2 rounded"> <?php echo e(__('invoice.show.actions.reject')); ?></button>
                </form>
                <?php endif; ?>
            </div>
            <div class="flex justify-end">
                <a href="<?php echo e(route('admin.invoices.edit', $invoice->id)); ?>"
                    class="bg-green-700 text-white px-4 py-2 rounded me-2"> <?php echo e(__('invoice.show.actions.edit')); ?></a>
                <form action="<?php echo e(route('admin.invoices.destroy', $invoice->id)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                        onclick="return confirm('<?php echo e(__('invoice.show.actions.confirm_delete')); ?>')"
                        class="bg-red-700 text-white px-4 py-2 rounded me-2">
                        <?php echo e(__('invoice.show.actions.delete')); ?>

                    </button>
                </form>
                <a href="<?php echo e(route('admin.invoices.index')); ?>" class="bg-gray-300 px-4 py-2 rounded"><?php echo e(__('invoice.show.actions.back')); ?></a>
            </div>
        </div>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
        <div class="flex justify-between space-x-3 mt-6">
            <div class="flex justify-start">
                <?php if($invoice->statut !== 'approuvé'): ?>
                <form action="<?php echo e(route('super_admin.invoices.approve', $invoice->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="bg-green-600 text-white px-4 py-2 rounded me-2"> <?php echo e(__('invoice.show.actions.approve')); ?></button>
                </form>
                <?php endif; ?>
                <?php if($invoice->statut !== 'rejeté'): ?>
                <form action="<?php echo e(route('super_admin.invoices.reject', $invoice->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="bg-red-600 text-white px-4 py-2 rounded"> <?php echo e(__('invoice.show.actions.reject')); ?></button>
                </form>
                <?php endif; ?>
            </div>
            <div class="flex justify-end">
                <a href="<?php echo e(route('super_admin.invoices.edit', $invoice->id)); ?>"
                    class="bg-green-700 text-white px-4 py-2 rounded me-2"> <?php echo e(__('invoice.show.actions.edit')); ?></a>
                <form action="<?php echo e(route('super_admin.invoices.destroy', $invoice->id)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                        onclick="return confirm('<?php echo e(__('invoice.show.actions.confirm_delete')); ?>')"
                        class="bg-red-700 text-white px-4 py-2 rounded me-2">
                        <?php echo e(__('invoice.show.actions.delete')); ?>

                    </button>
                </form>
                <a href="<?php echo e(route('super_admin.invoices.index')); ?>" class="bg-gray-300 px-4 py-2 rounded"><?php echo e(__('invoice.show.actions.back')); ?></a>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const showButton = document.getElementById("show-articles");
        const modal = document.getElementById("articles-modal");
        const closeBtn = document.getElementById("close-modal");

        if (showButton && modal && closeBtn) {
            showButton.addEventListener("click", () => {
                modal.classList.remove("hidden");
            });

            closeBtn.addEventListener("click", () => {
                modal.classList.add("hidden");
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\invoices\show.blade.php ENDPATH**/ ?>