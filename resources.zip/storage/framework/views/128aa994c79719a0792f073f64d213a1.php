<?php $__env->startSection('title', __('invoice.invoice_create.title')); ?>
<?php $__env->startSection('page_title', __('invoice.invoice_create.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">

    <?php if(session('error')): ?>
    <div class="mb-4 rounded-lg bg-red-100 border border-red-300 text-red-800 px-4 py-3">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
    <form method="POST" action="<?php echo e(route('admin.invoices.store')); ?>" enctype="multipart/form-data">
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
        <form method="POST" action="<?php echo e(route('super_admin.invoices.store')); ?>" enctype="multipart/form-data">
            <?php endif; ?>

            <?php echo csrf_field(); ?>

            
            <div class="mb-4">
                <label class="block text-gray-700"><?php echo e(__('invoice.invoice_create.user_label')); ?></label>
                <select name="user_id" class="w-full border-gray-300 rounded px-3 py-2" required>
                    <option value=""><?php echo e(__('invoice.invoice_create.choose_user')); ?></option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-4">
                <label class="block text-gray-700"><?php echo e(__('invoice.invoice_create.status_label')); ?></label>
                <select name="statut" class="w-full border-gray-300 rounded px-3 py-2">
                    <option value="en_attente"><?php echo e(__('invoice.invoice_create.status.pending')); ?></option>
                    <option value="approuvé"><?php echo e(__('invoice.invoice_create.status.approved')); ?></option>
                    <option value="rejeté"><?php echo e(__('invoice.invoice_create.status.rejected')); ?></option>
                </select>
                <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-4">
                <label for="file" class="block text-sm font-medium"><?php echo e(__('invoice.invoice_create.upload_label')); ?></label>
                <input type="file" name="file" id="file" class="w-full p-2 border rounded" accept="image/*,application/pdf">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-sm"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="flex justify-end space-x-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <a href="<?php echo e(route('admin.invoices.index')); ?>" class="px-4 py-2 bg-gray-300 rounded mx-2">
                    <?php echo e(__('invoice.invoice_create.cancel')); ?>

                </a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
                <a href="<?php echo e(route('super_admin.invoices.index')); ?>" class="px-4 mx-2 py-2 bg-gray-300 rounded">
                    <?php echo e(__('invoice.invoice_create.cancel')); ?>

                </a>
                <?php endif; ?>

                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                    <?php echo e(__('invoice.invoice_create.save')); ?>

                </button>
            </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\invoices\create.blade.php ENDPATH**/ ?>