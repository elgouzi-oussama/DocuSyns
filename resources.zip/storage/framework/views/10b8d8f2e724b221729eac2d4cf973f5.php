<?php $__env->startSection('title', __('licenses.title')); ?>
<?php $__env->startSection('page_title', __('licenses.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-10 px-6 py-8 bg-white rounded-2xl shadow-md">

    
    <form action="<?php echo e(route('super_admin.licenses.upgrade')); ?>" method="POST" class="mb-8">
        <?php echo csrf_field(); ?>
        <div class="flex flex-col md:flex-row md:items-center md:space-x-4">
            <div class="flex-1">
                <label class="text-sm font-medium text-gray-600 mb-1 block">
                    <?php echo e(__('licenses.upgrade_label')); ?>

                </label>
                <div class="flex flex-col md:flex-row md:space-x-4 gap-2">
                    <input type="text" name="upgrade_key" placeholder="<?php echo e(__('licenses.upgrade_placeholder')); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    <button type="submit"
                        class="w-full  md:w-auto bg-blue-600 text-white font-medium px-6 py-2 rounded-lg hover:bg-blue-700 transition">
                        <?php echo e(__('licenses.upgrade_button')); ?>

                    </button>
                </div>
            </div>
        </div>
    </form>

    
    <?php if(session('status')): ?>
    <div class="p-4 mb-6 rounded-lg text-center font-medium
            <?php echo e(str_contains(session('status'), '❌') ? 'bg-red-100 text-red-700 border border-red-300' : 'bg-green-100 text-green-700 border border-green-300'); ?>">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    
    <div class="mb-10 text-gray-700 leading-relaxed">
        <h2 class="text-2xl font-semibold text-gray-800 mb-3"><?php echo e(__('licenses.about_title')); ?></h2>
        <p><?php echo e(__('licenses.about_p1')); ?></p>
        <p class="mt-3"><?php echo e(__('licenses.about_p2')); ?></p>
        <p class="mt-3"><?php echo e(__('licenses.about_p3')); ?></p>
    </div>

    
    <h2 class="text-2xl font-bold text-gray-800 text-center mb-8"><?php echo e(__('licenses.plans_title')); ?></h2>

    <div class="grid md:grid-cols-3 gap-6">
        <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $helper = app(App\Helpers\SystemHelper::class);
        $checkli = $helper->hasLicenseType($license->_name);

        $features = json_decode($license->features, true);
        $totalAccounts = ($features['users'] ?? 0) + ($features['admins'] ?? 0);
        ?>
        <div class="relative border rounded-2xl shadow-sm hover:shadow-lg  <?php echo e($checkli ? 'bg-blue-200' : 'bg-gray-50'); ?> p-6 transition-all duration-300 flex flex-col items-center text-center">

            
            <h3 class="text-xl font-bold text-blue-700 mb-3 uppercase tracking-wide">
                <?php echo e($license->_name); ?>

            </h3>

            
            <div class="text-gray-600 mb-5 space-y-2">
                <p><strong><?php echo e($totalAccounts); ?></strong> <?php echo e(__('licenses.total_accounts')); ?></p>
                <p><strong><?php echo e($features['admins'] ?? '-'); ?></strong> <?php echo e(__('licenses.admins_max')); ?></p>
                <p><strong><?php echo e($features['users'] ?? '-'); ?></strong> <?php echo e(__('licenses.users_max')); ?></p>
                <p>
                    <?php echo e(__('licenses.storage_text', ['storage' => $features['storage'] ?? '-'])); ?>

                </p>
            </div>


            
            <p class="text-sm text-gray-500 mb-6">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isBasic')): ?>
                <?php echo e(__('licenses.desc_basic')); ?>

                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isPro')): ?>
                <?php echo e(__('licenses.desc_pro')); ?>

                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isEnterprise')): ?>
                <?php echo e(__('licenses.desc_enterprise')); ?>

                <?php endif; ?>
            </p>


        </div>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\licenses\index.blade.php ENDPATH**/ ?>