<?php $__env->startSection('title', __('messages.welcome_page') ); ?>
<?php $__env->startSection('page_title', __('messages.welcome_page') ); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero Section -->
<section class="flex-1 flex flex-col items-center justify-center text-center px-6">
    <h1 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
        <?php echo e(__('messages.welcome')); ?> <span class="text-blue-600">DocuSyns</span>
    </h1>
    <p class="text-gray-600 max-w-lg mb-8">
        <?php echo e(__('messages.inside_welcome')); ?>

    </p>

    <div class="flex space-x-4">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.create')): ?>
        <a href="<?php echo e(route('invoice.create')); ?>" class="bg-blue-600 text-white mx-3 px-6 py-3 rounded-lg hover:bg-blue-700 transition">
            ➕ <?php echo e(__('messages.add_invoice')); ?>

        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.index')): ?>
        <a href="<?php echo e(route('invoice.index')); ?>" class="border border-blue-600 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition">
            📄 <?php echo e(__('messages.view_invoices')); ?>

        </a>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('invoice.create')); ?>" class="bg-blue-600 text-white mx-3 px-6 py-3 rounded-lg hover:bg-blue-700 transition">
            ➕ <?php echo e(__('messages.add_invoice')); ?>

        </a>
        <a href="<?php echo e(route('invoice.index')); ?>" class="border border-blue-600 text-blue-600 px-6 py-3 rounded-lg hover:bg-blue-50 transition">
            📄 <?php echo e(__('messages.view_invoices')); ?>

        </a>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\index.blade.php ENDPATH**/ ?>