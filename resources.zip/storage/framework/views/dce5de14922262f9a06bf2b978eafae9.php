<?php $__env->startSection('title', __('admin.dashboard_title')); ?>
<?php $__env->startSection('page_title', __('admin.dashboard_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-md mx-auto mt-10 bg-white p-6 rounded-lg shadow">
    <h2 class="text-xl font-bold mb-4 text-center"><?php echo e(__('admin.change_password_title')); ?></h2>

    <form method="POST" action="<?php echo e(route('admin.password.update')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label class="block mb-1"><?php echo e(__('admin.new_password')); ?></label>
            <input type="password" name="password" class="w-full border rounded p-2" required>
        </div>
        <div class="mb-4">
            <label class="block mb-1"><?php echo e(__('admin.confirm_password')); ?></label>
            <input type="password" name="password_confirmation" class="w-full border rounded p-2" required>
        </div>
        <button class="w-full bg-blue-600 text-white py-2 rounded">
            <?php echo e(__('admin.change_button')); ?>

        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\sign\change-password.blade.php ENDPATH**/ ?>