<?php $__env->startSection('title', __('admin.dashboard.page_title')); ?>
<?php $__env->startSection('page_title', __('admin.dashboard.page_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="mb-4 rounded-lg bg-green-100 border border-green-300 text-green-800 px-4 py-3">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="mb-4 rounded-lg bg-red-100 border border-red-300 text-red-800 px-4 py-3">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="bg-white p-6 rounded-lg shadow-sm">
    <h3 class="text-xl font-medium text-gray-700 mb-4"><?php echo e(__('admin.dashboard.welcome_title')); ?></h3>
    <p class="text-gray-600"><?php echo e(__('admin.dashboard.welcome_text')); ?></p>

    <div class="grid grid-cols-3 gap-4 mt-6">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.index')): ?>
        <a href="<?php echo e(route('admin.invoices.index')); ?>" class="bg-blue-50 p-4 rounded-lg text-center">
            <h4 class="text-blue-700 text-lg font-semibold"><?php echo e($countinvoice); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.purchase_orders')); ?></p>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('invoice.index')): ?>
        <div class="bg-blue-50 p-4 rounded-lg text-center">
            <h4 class="text-blue-700 text-lg font-semibold"><?php echo e($countinvoice); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.purchase_orders')); ?></p>
        </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.index')): ?>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-green-50 p-4 rounded-lg text-center">
            <h4 class="text-green-700 text-lg font-semibold"><?php echo e($countuser); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.users')); ?></p>
        </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('user.index')): ?>
        <div class="bg-green-50 p-4 rounded-lg text-center">
            <h4 class="text-green-700 text-lg font-semibold"><?php echo e($countuser); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.users')); ?></p>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isAdmin')): ?>
        <a href="<?php echo e(route('super_admin.invoices.index')); ?>" class="bg-blue-50 p-4 rounded-lg text-center">
            <h4 class="text-blue-700 text-lg font-semibold"><?php echo e($countinvoice); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.purchase_orders')); ?></p>
        </a>
        <a href="<?php echo e(route('super_admin.invoices.index')); ?>" class="bg-green-50 p-4 rounded-lg text-center">
            <h4 class="text-green-700 text-lg font-semibold"><?php echo e($countuser); ?></h4>
            <p class="text-gray-600 text-sm"><?php echo e(__('admin.dashboard.users')); ?></p>
        </a>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>