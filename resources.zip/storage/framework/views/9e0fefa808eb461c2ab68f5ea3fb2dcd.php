<?php $__env->startSection('title', __('messages.account_info')); ?>
<?php $__env->startSection('page_title', __('messages.profile_page_title')); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="m-4 bg-green-100 text-green-800 border border-green-300 rounded-lg px-4 py-3 text-lg">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<div class="flex-1 flex flex-col items-center text-lg justify-center px-6 py-6">
    <h2 class="text-xl font-semibold mb-2"><?php echo e(__('messages.account_info')); ?></h2>

    <div class="d-block bg-white max-w-xl p-8 rounded-lg shadow-lg mx-auto">
        <div class="mb-6">
            <p><strong><?php echo e(__('messages.name')); ?> :</strong> <?php echo e($user->name); ?></p>
            <p><strong><?php echo e(__('messages.email')); ?> :</strong> <?php echo e($user->email); ?></p>
            <p><strong><?php echo e(__('messages.role')); ?> :</strong> <?php echo e(ucfirst($user->role)); ?></p>
            <p><strong><?php echo e(__('messages.created_at')); ?> :</strong> <?php echo e($user->created_at->format('d/m/Y H:i')); ?></p>
            <p><strong><?php echo e(__('messages.updated_at')); ?> :</strong> <?php echo e($user->updated_at->format('d/m/Y H:i')); ?></p>
        </div>

        <div class="flex justify-between">
            <a href="<?php echo e(route('index')); ?>" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">
                <?php echo e(__('messages.back')); ?>

            </a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile.edit')): ?>
            <a href="<?php echo e(route('profile.edit')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                <?php echo e(__('messages.edit_profile')); ?>

            </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\profile\show.blade.php ENDPATH**/ ?>