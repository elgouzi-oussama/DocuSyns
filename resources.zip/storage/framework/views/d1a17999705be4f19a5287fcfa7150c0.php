<?php $__env->startSection('title', 'Créer Bon de commande | DocuSyns'); ?>
<?php $__env->startSection('page_title', 'Créer Bon de commande | DocuSyns'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('error')): ?>
<div
    x-data="{ show: true }"
    x-show="show"
    x-transition
    x-init="setTimeout(() => show = false, 4000)"
    class="m-4 rounded-lg bg-red-100 border border-red-300 text-red-800 px-4 py-3 flex items-center justify-between"
    role="alert">
    <span class="font-medium"><?php echo e(session('error')); ?></span>
    <button
        type="button"
        class="text-red-600 hover:text-red-800 font-bold text-xl leading-none ml-4"
        @click="show = false">
        ×
    </button>
</div>
<?php endif; ?>

<?php if(session('success')): ?>
<div
    x-data="{ show: true }"
    x-show="show"
    x-transition
    x-init="setTimeout(() => show = false, 4000)"
    class="m-4 rounded-lg bg-green-100 border border-green-300 text-green-800 px-4 py-3 flex items-center justify-between"
    role="alert">
    <span class="font-medium"><?php echo e(session('success')); ?></span>
    <button
        type="button"
        class="text-green-600 hover:text-green-800 font-bold text-xl leading-none ml-4"
        @click="show = false">
        ×
    </button>
</div>
<?php endif; ?>

<div class="bg-gray-100 flex-1 flex items-center justify-center p-6">
    <div class="w-full max-w-4xl mx-auto p-8">
        <h1 class="text-2xl font-bold mb-4"><?php echo e(__('messages.create_order')); ?></h1>

        <div class="flex gap-2 mb-4">
            <a href="<?php echo e(route('invoice.index')); ?>"
                class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded inline-block transition">
                <?php echo e(__('messages.back_to_invoices')); ?>

            </a>
            <button
                type="button"
                onclick="toggleTemplateForm()"
                class=" hover:bg-blue-400 px-4 py-2 rounded border transition bg-blue-600 text-white">
                <span id="toggle-text"><?php echo e(__('messages.new_template')); ?></span>
            </button>
        </div>

        
        <form action="<?php echo e(route('invoice.store')); ?>"
            id="create-form"
            method="POST"
            enctype="multipart/form-data"
            class="bg-white p-6 rounded shadow">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="file" class="block text-sm font-medium mb-2">
                    <?php echo e(__('messages.upload_file')); ?>

                </label>
                <input type="file"
                    name="file"
                    id="file"
                    class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    accept="image/*,application/pdf">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit"
                class="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded transition">
                <?php echo e(__('messages.submit')); ?>

            </button>
        </form>

        
        <form action="<?php echo e(route('ai-invoice.store')); ?>"
            id="new-template" class="hidden bg-white p-6 rounded shadow mt-6"
            method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="file" class="block text-sm font-medium mb-2">
                    <?php echo e(__('messages.upload_file')); ?>

                </label>
                <input type="file"
                    name="file"
                    id="file"
                    class="w-full p-2 border rounded focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    accept="image/*,application/pdf">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit"
                class="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded transition">
                <?php echo e(__('messages.submit')); ?>

            </button>
        </form>


    </div>
</div>

<script>
    function toggleTemplateForm() {
        const newTemplate = document.getElementById("new-template");
        const createForm = document.getElementById("create-form");
        const toggleText = document.getElementById("toggle-text");

        if (newTemplate && createForm) {
            const isHidden = newTemplate.classList.contains("hidden");

            newTemplate.classList.toggle("hidden");
            createForm.classList.toggle("hidden");

            // Update button text
            if (toggleText) {
                toggleText.textContent = isHidden ?
                    "<?php echo e(__('messages.back_to_upload')); ?>" :
                    "<?php echo e(__('messages.new_template')); ?>";
            }
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\invoice\create.blade.php ENDPATH**/ ?>