<?php $__env->startSection('title', __('user.list.title')); ?>
<?php $__env->startSection('page_title', __('user.list.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm">

    <?php if(session('success')): ?>
    <div class="mb-4 <?php echo e(session('deleted') ? 'bg-red-100 border border-red-300 text-red-800' : 'bg-green-100 border border-green-300 text-green-800'); ?> px-4 py-3 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
    <div class="mb-4">
        <a href="<?php echo e(route('super_admin.users.permissions.index')); ?>" class="text-blue-600 hover:underline rounded bg-blue-50 p-2 text-lg">
            <?php echo e(__('user.list.manage_permissions')); ?>

        </a>
    </div>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.show')): ?>
    <div class="mb-4">
        <a href="<?php echo e(route('admin.users.permissions.index')); ?>" class="text-blue-600 hover:underline rounded bg-blue-50 p-2 text-lg">
            <?php echo e(__('user.list.manage_permissions')); ?>

        </a>
    </div>
    <?php endif; ?>

    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold text-gray-700"><?php echo e(__('user.list.title_table')); ?></h2>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
        <a href="<?php echo e(route('super_admin.users.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            + <?php echo e(__('user.list.add_user')); ?>

        </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.create')): ?>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            + <?php echo e(__('user.list.add_user')); ?>

        </a>
        <?php endif; ?>
    </div>

    <table class="w-full text-left border border-gray-200">
        <thead class="bg-gray-100">
            <tr>
                <th class="px-4 py-2 border-b">#</th>
                <th class="px-4 py-2 border-b"><?php echo e(__('user.list.name')); ?></th>
                <th class="px-4 py-2 border-b"><?php echo e(__('user.list.email')); ?></th>
                <th class="px-4 py-2 border-b"><?php echo e(__('user.list.role')); ?></th>
                <th class="px-4 py-2 border-b text-center"><?php echo e(__('user.list.actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-2 border-b"><?php echo e($user->id); ?></td>
                <td class="px-4 py-2 border-b"><?php echo e($user->name); ?></td>
                <td class="px-4 py-2 border-b"><?php echo e($user->email); ?></td>
                <td class="px-4 py-2 border-b"><?php echo e(ucfirst($user->role ?? 'user')); ?></td>
                <td class="px-4 py-2 border-b text-center space-x-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
                    <a href="<?php echo e(route('super_admin.users.edit', $user)); ?>" class="text-yellow-600 mx-2 hover:underline"><?php echo e(__('user.list.edit')); ?></a>

                    <form action="<?php echo e(route('super_admin.users.destroy', $user)); ?>" method="POST" class=" inline"
                        onsubmit="return confirm('<?php echo e(__('user.list.delete_confirm')); ?>');">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="text-red-600 hover:underline"><?php echo e(__('user.list.delete')); ?></button>
                    </form>

                    <a href="<?php echo e(route('super_admin.users.show', $user)); ?>" class="text-blue-600 hover:underline"><?php echo e(__('user.list.show')); ?></a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.edit')): ?>
                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="text-yellow-600 hover:underline"><?php echo e(__('user.list.edit')); ?></a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.delete')): ?>
                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" class="inline"
                        onsubmit="return confirm('<?php echo e(__('user.list.delete_confirm')); ?>');">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="text-red-600 hover:underline"><?php echo e(__('user.list.delete')); ?></button>
                    </form>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.show' , $user)): ?>
                    <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="text-blue-600 hover:underline"><?php echo e(__('user.list.show')); ?></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="px-4 py-3 text-center text-gray-500"><?php echo e(__('user.list.no_users')); ?></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\users\index.blade.php ENDPATH**/ ?>