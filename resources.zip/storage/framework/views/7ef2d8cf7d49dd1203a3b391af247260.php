<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>


    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        html[dir="rtl"] {
            direction: rtl;
        }

        html[dir="rtl"] .space-x-2>*+*,
        html[dir="rtl"] .space-x-3>*+*,
        html[dir="rtl"] .space-x-4>*+*,
        html[dir="rtl"] .space-x-6>*+* {
            margin-left: 0;
            margin-right: 0.5rem;
        }

        .blur-overlay {
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }

        .payment-modal {
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen flex flex-col select-none">
    <!-- Navbar -->
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
            <div class="flex items-center <?php echo e(app()->getLocale() === 'ar' ? 'space-x-reverse' : ''); ?> space-x-2">
                <span class="text-2xl font-bold text-blue-600">DocuSyns</span>
            </div>

            <div class="hidden md:flex <?php echo e(app()->getLocale() === 'ar' ? 'space-x-reverse' : ''); ?> space-x-6">
                <a href="<?php echo e(route('index')); ?>" class="text-gray-700 hover:text-blue-600 transition"><?php echo e(__('messages.home')); ?></a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.index')): ?>
                <a href="<?php echo e(route('invoice.index')); ?>" class="text-gray-700 hover:text-blue-600 transition"><?php echo e(__('messages.orders')); ?></a>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('invoice.index')); ?>" class="text-gray-700 hover:text-blue-600 transition"><?php echo e(__('messages.orders')); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('user.rapports.index')); ?>" class="text-gray-700 hover:text-blue-600 transition"><?php echo e(__('messages.reports')); ?></a>
                <a href="<?php echo e(route('user.contact.index')); ?>" class="text-gray-700 hover:text-blue-600 transition"><?php echo e(__('messages.contact')); ?></a>
            </div>


            <div class="flex items-center <?php echo e(app()->getLocale() === 'ar' ? 'space-x-reverse' : ''); ?> space-x-4">
                <!-- Language Switcher -->
                <div class="flex <?php echo e(app()->getLocale() === 'ar' ? 'space-x-reverse' : ''); ?> space-x-2">
                    <?php $__currentLoopData = config('app.supported_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('set-locale', $locale)); ?>"
                        class="px-3 py-2 rounded-lg font-medium text-sm transition
                            <?php echo e(app()->getLocale() === $locale 
                                ? 'bg-blue-600 text-white' 
                                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'); ?>">
                        <?php if($locale === 'en'): ?> EN
                        <?php elseif($locale === 'fr'): ?> FR
                        <?php elseif($locale === 'ar'): ?> AR
                        <?php endif; ?>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('logout')); ?>" class="bg-red-400 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">
                    <?php echo e(__('messages.logout')); ?>

                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile.show')): ?>
                <a href="<?php echo e(route('profile.show')); ?>" class="">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('css-profile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-10 h-10 p-1 rounded-full hover:bg-gray-400 transition']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </a>
                <?php endif; ?>
                <?php else: ?>
                <a href="/signin" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                    <?php echo e(__('messages.login')); ?>

                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Payment Notice Modal - Show if trial expired -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTrialEnded')): ?>
    <div class="fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-sm bg-black/30">
        <div class="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full shadow-2xl border border-white/20 payment-modal">
            <div class="text-center">
                <!-- Icon -->
                <div class="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>

                <!-- Title -->
                <h2 class="text-3xl font-bold text-gray-800 mb-4">
                    <?php echo e(__('messages.trial_ended_title', ['default' => 'Free Trial Ended'])); ?>

                </h2>

                <!-- Message -->
                <p class="text-gray-600 mb-6 leading-relaxed">
                    <?php echo e(__('messages.trial_ended_message', ['default' => 'Your 30-day free trial has come to an end. To continue using our amazing features and services, please upgrade to a paid plan.'])); ?>

                </p>


            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <footer class="flex bg-white border-t mt-10 py-4 text-center text-gray-500 text-sm">
        <p class="font-semibold text-gray-800  text-start  w-[40%] px-3 ">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTrial')): ?>
            <?php echo e(__('messages.trial_message')); ?>


            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isPro')): ?>
            <?php echo e(__('messages.pro_message')); ?>


            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isBasic')): ?>
            <?php echo e(__('messages.basic_message')); ?>


            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isEnterprise')): ?>

            <?php echo e(__('messages.enterprise_message')); ?>


            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('noLicense')): ?>
            <?php echo e(__('messages.trial_expired_message')); ?>


            <?php endif; ?>
        </p>
        <p class="w-[60%] text-start"> © <?php echo e(date('Y')); ?> DocuSyns. <?php echo e(__('messages.all_rights_reserved')); ?></p>
    </footer>

    </div>
</body>

</html><?php /**PATH E:\work\New folder\DocuSyns\resources\views/user/layout.blade.php ENDPATH**/ ?>