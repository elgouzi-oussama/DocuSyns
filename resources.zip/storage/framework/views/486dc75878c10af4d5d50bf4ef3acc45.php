<?php $__env->startSection('title', __('user.edit.title')); ?>
<?php $__env->startSection('page_title', __('user.edit.page_title')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-4 rounded-lg shadow-sm max-w-xl text-lg mx-auto">
    <form method="POST" action="<?php echo e(route('super_admin.users.update', $user)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-gray-700 mb-1"><?php echo e(__('user.edit.role')); ?></label>
            <select name="role"
                class="w-full border-gray-400 rounded px-3 py-2 bg-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required>
                <option value=""><?php echo e(__('user.edit.select_role')); ?></option>
                <option value="user" <?php echo e(old('role', $user->role ?? '') == 'user' ? 'selected' : ''); ?>>
                    <?php echo e(__('user.edit.role_user')); ?>

                </option>
                <option value="admin" <?php echo e(old('role', $user->role ?? '') == 'admin' ? 'selected' : ''); ?>>
                    <?php echo e(__('user.edit.role_admin')); ?>

                </option>
            </select>
            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.edit.name')); ?></label>
            <input type="text" name="name" class="w-full border-gray-400 bg-gray-300 rounded px-3 py-2"
                value="<?php echo e(old('name', $user->name)); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.edit.email')); ?></label>
            <input type="email" name="email" class="w-full border-gray-400 bg-gray-300 rounded px-3 py-2"
                value="<?php echo e(old('email', $user->email)); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.edit.new_password')); ?></label>
            <input type="password" name="password" class="w-full border-gray-400 bg-gray-300 rounded px-3 py-2">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.edit.confirm_password')); ?></label>
            <input type="password" name="password_confirmation" class="w-full bg-gray-300 border-gray-400 rounded px-3 py-2">
        </div>

        <div class="flex justify-end space-x-3">
            <a href="<?php echo e(route('super_admin.users.index')); ?>" class="px-4 py-2 bg-gray-300 rounded">
                <?php echo e(__('user.edit.cancel')); ?>

            </a>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                <?php echo e(__('user.edit.update')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-xl mx-auto">
    <h1 class="text-xl font-bold mb-4"><?php echo e(__('user.edit.manage_permissions')); ?></h1>

    <form method="POST" action="<?php echo e(route('super_admin.users.permissions', $user)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-1 gap-4 p-4 bg-white rounded-lg shadow-sm text-lg">

            <h3 class="col-span-full text-lg font-semibold text-gray-700 mb-2">
                <?php echo e(__('user.edit.invoice_permissions')); ?>

            </h3>

            <label><input type="checkbox" name="permissions[]" value="invoice.index" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.index') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.view_invoices')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.show" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.show') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.show_invoice')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.create" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.create') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.create_invoice')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.edit" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.edit') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.edit_invoice')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.delete" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.delete') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.delete_invoice')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.approve" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.approve') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.approve_invoice')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="invoice.reject" class="mr-2"
                    <?php echo e($user->hasPermission('invoice.reject') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.reject_invoice')); ?>

            </label>

            <?php if($user->role !== "user"): ?>
            <h3 class="col-span-full text-lg font-semibold text-gray-700 mt-4 mb-2">
                <?php echo e(__('user.edit.user_permissions')); ?>

            </h3>

            <label><input type="checkbox" name="permissions[]" value="user.index" class="mr-2"
                    <?php echo e($user->hasPermission('user.index') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.view_users')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="user.show" class="mr-2"
                    <?php echo e($user->hasPermission('user.show') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.show_user')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="user.create" class="mr-2"
                    <?php echo e($user->hasPermission('user.create') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.create_user')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="user.edit" class="mr-2"
                    <?php echo e($user->hasPermission('user.edit') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.edit_user')); ?>

            </label>

            <label><input type="checkbox" name="permissions[]" value="user.delete" class="mr-2"
                    <?php echo e($user->hasPermission('user.delete') ? 'checked' : ''); ?>>
                <?php echo e(__('user.edit.perms.delete_user')); ?>

            </label>
            <?php endif; ?>
        </div>

        <div class="flex justify-end space-x-3 mt-4">
            <a href="<?php echo e(route('super_admin.users.index')); ?>" class="px-4 py-2 bg-gray-300 mx-3 rounded">
                <?php echo e(__('user.edit.cancel')); ?>

            </a>
            <button type="submit" class="px-4   py-2 bg-blue-600 text-white rounded">
                <?php echo e(__('user.edit.update')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>