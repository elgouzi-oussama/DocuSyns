<?php $__env->startSection('title', __('messages.invoice_details_title')); ?>
<?php $__env->startSection('page_title', __('messages.invoice_details_title')); ?>

<?php $__env->startSection('content'); ?>

<div>
    <?php if(session('success')): ?>
    <div
        x-data="{ show: true }"
        x-show="show"
        x-transition
        x-init="setTimeout(() => show = false, 4000)"
        class="mb-4 rounded-lg bg-green-100 border border-green-300 text-green-800 px-4 py-3 flex items-center justify-between"
        role="alert">
        <span class="font-medium"><?php echo e(session('success')); ?></span>
        <button
            type="button"
            class="text-green-600 hover:text-green-800 font-bold text-xl leading-none ml-4"
            @click="show = false">
            ×
        </button>
    </div>
    <?php endif; ?>

    <div class="bg-gray-100 min-h-screen flex items-center justify-center p-6">
        <div class="bg-white shadow-lg rounded-2xl p-8 w-full max-w-6xl">
            <h1 class="text-2xl font-semibold text-gray-800 mb-6 text-center">
                📄 <?php echo e(__('messages.invoice_details')); ?>

            </h1>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-5 text-gray-700">

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.reference_commande')); ?></p>
                    <p class="font-medium"><?php echo e($invoice->reference_commande); ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.date_commande')); ?></p>
                    <p class="font-medium"><?php echo e(\Carbon\Carbon::parse($invoice->date_commande)->format('d/m/Y')); ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.nom_fournisseur')); ?></p>
                    <p class="font-medium"><?php echo e($invoice->nom_fournisseur); ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.code_fournisseur')); ?></p>
                    <p class="font-medium"><?php echo e($invoice->code_fournisseur ?? '-'); ?></p>
                </div>

                <div class="md:col-span-2">
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.commande_par')); ?></p>
                    <p class="font-medium whitespace-pre-line"><?php echo e($invoice->commande_par); ?></p>
                </div>

                <div class="md:col-span-2">
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.commande_a')); ?></p>
                    <p class="font-medium whitespace-pre-line"><?php echo e($invoice->commande_a); ?></p>
                </div>

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.montant_ht')); ?></p>
                    <p>
                        <?php if(app()->getLocale() === 'ar'): ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_ht, 2, ',', ' ')); ?>&lrm;</span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php else: ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_ht, 2, ',', ' ')); ?></span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php endif; ?>
                    </p>
                </div>
                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.montant_tva')); ?></p>
                    <p>
                        <?php if(app()->getLocale() === 'ar'): ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_tva, 2, ',', ' ')); ?>&lrm;</span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php else: ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_tva, 2, ',', ' ')); ?></span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php endif; ?>
                    </p>
                </div>

                <div>
                    <p class="text-sm text-gray-500"><?php echo e(__('messages.montant_ttc')); ?></p>
                    <p>
                        <?php if(app()->getLocale() === 'ar'): ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?>&lrm;</span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php else: ?>
                        <span dir="ltr">
                            <?php echo e(number_format($invoice->montant_ttc, 2, ',', ' ')); ?></span>
                        <span><?php echo e(__('admin.currency')); ?></span>
                        <?php endif; ?>
                    </p>
                </div>

                <?php if($invoice->file): ?>
                <div class="md:col-span-2">
                    <p class="text-sm text-gray-500 mb-1"><?php echo e(__('messages.fichier_associe')); ?></p>
                    <a href="<?php echo e(asset('storage/' . $invoice->file)); ?>" target="_blank"
                        class="text-blue-600 hover:underline">
                        📎 <?php echo e(__('messages.view_file')); ?>

                    </a>
                </div>
                <?php endif; ?>
                <div class=" md:col-span-2">
                    <?php if($invoice->articles): ?>
                    <div class="mt-6 text-start  ">
                        <!-- <button id="show-articles"
                    class="bg-gray-300 text-black px-3 p-2 hover:bg-gray-700 hover:text-white  rounded-lg">
                    📄 Voir les articles
                </button> -->
                    </div>


                    <div>
                        <h2 class="text-xl font-bold mb-4">Articles</h2>

                        <table class="min-w-full border border-gray-300 text-sm">
                            <thead class="bg-gray-800 text-white">
                                <tr>
                                    <?php $__currentLoopData = array_keys($invoice->articles[0] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="px-3 py-2 border-b"><?php echo e($key); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoice->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50">
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="px-3 py-2 border-b"><?php echo e($value); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>


                    </div>
                    <?php endif; ?>
                </div>


            </div>

            <div class="pt-6 flex justify-between">
                <a href="<?php echo e(route('invoice.index')); ?>"
                    class="px-6 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition">
                    <?php echo e(__('messages.back')); ?>

                </a>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.edit')): ?>
                <a href="<?php echo e(route('invoice.edit', $invoice->id)); ?>"
                    class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                    <?php echo e(__('messages.edit')); ?>

                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\invoice\show.blade.php ENDPATH**/ ?>