<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', __('admin.title')); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>


    <style>
        /* RTL adjustments */
        [dir="rtl"] body {
            direction: rtl;
            text-align: right;
        }

        [dir="rtl"] .space-x-2>*+* {
            margin-right: 0.5rem;
            margin-left: 0;
        }

        [dir="rtl"] .space-x-3>*+* {
            margin-right: 0.75rem;
            margin-left: 0;
        }

        [dir="rtl"] .text-left {
            text-align: right !important;
        }

        [dir="rtl"] .text-right {
            text-align: left !important;
        }

        /* Fixed sidebar positioning for RTL */
        [dir="rtl"] aside {
            left: auto !important;
            right: 0 !important;
        }

        [dir="rtl"] main {
            margin-left: 0 !important;
            margin-right: 15rem !important;
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen select-none">


    <aside class="fixed top-0 left-0 bg-white shadow-md grid grid-rows-[auto_1fr_auto_auto] h-screen w-60">
        <!-- Header -->
        <div class="p-6 border-b flex justify-center items-center">
            <h1 class="text-2xl font-bold text-blue-600 select-none text-center">
                <?php echo e(__('admin.sidebar.title')); ?>

            </h1>
        </div>

        <!-- Navigation -->
        <nav class="p-4 space-y-2 overflow-y-auto">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                🏠 <?php echo e(__('admin.sidebar.dashboard')); ?>

            </a>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice.index')): ?>
            <a href="<?php echo e(route('admin.invoices.index')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('admin.invoices.*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                📄 <?php echo e(__('admin.sidebar.invoices')); ?>

            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.index')): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('admin.users.*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                👤 <?php echo e(__('admin.sidebar.users')); ?>

            </a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile.show')): ?>
            <a href="<?php echo e(route('admin.profile.show')); ?>"
                class="block px-3 py-2 text-gray-700 hover:bg-blue-50">
                ⚙️ <?php echo e(__('admin.sidebar.settings')); ?>

            </a>
            <?php endif; ?>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
            <a href="<?php echo e(route('super_admin.dashboard')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('super_admin.dashboard') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                🏠 <?php echo e(__('admin.sidebar.dashboard')); ?>

            </a>

            <a href="<?php echo e(route('super_admin.invoices.index')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('super_admin.invoices.*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                📄 <?php echo e(__('admin.sidebar.invoices')); ?>

            </a>

            <a href="<?php echo e(route('super_admin.users.index')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('super_admin.users.*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                👤 <?php echo e(__('admin.sidebar.users')); ?>

            </a>
            <a href="<?php echo e(route('super_admin.licenses.index')); ?>"
                class="block px-3 py-2 rounded hover:bg-blue-50 
           <?php echo e(request()->routeIs('super_admin.licenses.*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?>">
                🔑 <?php echo e(__('admin.sidebar.licenses')); ?>

            </a>

            <a href="<?php echo e(route('super_admin.profile.show')); ?>"
                class="block px-3 py-2 text-gray-700 hover:bg-blue-50">
                ⚙️ <?php echo e(__('admin.sidebar.settings')); ?>

            </a>
            <?php endif; ?>
        </nav>

        <div class="bg-gray-100 text-gray-800 px-4 py-2 border-gray-300">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTrial')): ?>
            <h3 class="font-semibold mb-2">
                <?php echo e(__('messages.trial_message')); ?>

            </h3>

            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isPro')): ?>
            <h3 class="font-semibold mb-2">
                <?php echo e(__('messages.pro_message')); ?>

            </h3>

            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isBasic')): ?>
            <h3 class="font-semibold mb-2">
                <?php echo e(__('messages.basic_message')); ?>

            </h3>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isEnterprise')): ?>
            <h3 class="font-semibold mb-2">
                <?php echo e(__('messages.enterprise_message')); ?>

            </h3>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('noLicense')): ?>
            <h3 class="font-semibold mb-2">
                <?php echo e(__('messages.trial_expired_message')); ?>

            </h3>
            <?php endif; ?>
        </div>


        <!-- Language Switcher -->
        <div class="p-4 border-t bg-gray-50 flex justify-center items-center gap-2 <?php echo e(app()->getLocale() === 'ar' ? 'flex-row-reverse' : ''); ?>">
            <?php $__currentLoopData = config('app.supported_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('set-locale', $locale)); ?>"
                class="px-3 py-2 rounded-lg font-medium text-sm transition
                      <?php echo e(app()->getLocale() === $locale 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'); ?>">
                <?php if($locale === 'en'): ?> EN
                <?php elseif($locale === 'fr'): ?> FR
                <?php elseif($locale === 'ar'): ?> AR
                <?php endif; ?>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </aside>



    <!-- Main Content -->
    <main class="ml-60 p-6">
        <header class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-semibold text-gray-700"><?php echo $__env->yieldContent('page_title'); ?></h2>

            <div class="<?php echo e(app()->getLocale() === 'ar' ? 'flex-row-reverse space-x-reverse' : ''); ?>">
                <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">
                        <?php echo e(__('admin.logout')); ?>

                    </button>
                </form>
            </div>
        </header>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isTrialEnded')): ?>
    <div class="fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-sm bg-black/30">
        <div class="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full shadow-2xl border border-white/20 payment-modal">
            <div class="text-center">
                <!-- Icon -->
                <div class="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>

                <!-- Title -->
                <h2 class="text-3xl font-bold text-gray-800 mb-4">
                    <?php echo e(__('messages.trial_ended_title', ['default' => 'Free Trial Ended'])); ?>

                </h2>

                <!-- Message -->
                <p class="text-gray-600 mb-6 leading-relaxed">
                    <?php echo e(__('messages.trial_ended_message', ['default' => 'Your 30-day free trial has come to an end. To continue using our amazing features and services, please upgrade to a paid plan.'])); ?>

                </p>


            </div>
        </div>
    </div>
    <?php endif; ?>


</body>

</html><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\layout.blade.php ENDPATH**/ ?>