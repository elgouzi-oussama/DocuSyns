<?php $__env->startSection('title', __('user.create_title')); ?>
<?php $__env->startSection('page_title', __('user.add_user')); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-sm max-w-lg mx-auto">
    <form method="POST" action="<?php echo e(route('super_admin.users.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.name')); ?></label>
            <input type="text" name="name" class="w-full bg-gray-200 border-gray-300 rounded px-3 py-2"
                value="<?php echo e(old('name')); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.email')); ?></label>
            <input type="email" name="email" class="w-full bg-gray-200  border-gray-300 rounded px-3 py-2"
                value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.password')); ?></label>
            <input type="password" name="password" class="w-full bg-gray-200  border-gray-300 rounded px-3 py-2" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block text-gray-700"><?php echo e(__('user.confirm_password')); ?></label>
            <input type="password" name="password_confirmation" class="w-full  bg-gray-200 border-gray-300 rounded px-3 py-2" required>
        </div>

        <!-- ✅ Role Selection -->
        <div class="mb-6">
            <label class="block text-gray-700 mb-1"><?php echo e(__('user.role')); ?></label>
            <select name="role"
                class="w-full border-gray-300 rounded bg-gray-200  px-3 py-2  focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required>
                <option value=""><?php echo e(__('user.select_role')); ?></option>
                <option value="user" <?php echo e(old('role') == 'user' ? 'selected' : ''); ?>><?php echo e(__('user.role_user')); ?></option>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperAdmin')): ?>
                <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>><?php echo e(__('user.role_admin')); ?></option>
                <?php endif; ?>
            </select>
            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex justify-end space-x-3">
            <a href="<?php echo e(route('super_admin.users.index')); ?>" class="px-4 mx-4 py-2 bg-gray-300 rounded">
                <?php echo e(__('user.cancel')); ?>

            </a>
            <button type="submit" class="px-4 py-2 bg-blue-600  text-white rounded">
                <?php echo e(__('user.save')); ?>

            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\work\New folder\DocuSyns\resources\views\admin\users\create.blade.php ENDPATH**/ ?>