<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(__('auth.login_title')); ?> | DocuSyns</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f3f4f6;
        }

        .form-card {
            background-color: #fff;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.06);
        }

        .input-field {
            background-color: #f9fafb;
        }

        .input-field:focus {
            background-color: #fff;
            border-color: #d1d5db;
            box-shadow: 0 0 0 3px rgba(209, 213, 219, 0.4);
        }

        .btn-primary {
            background-color: #4b5563;
        }

        .btn-primary:hover {
            background-color: #374151;
        }
    </style>
</head>

<body class="min-h-screen flex items-center justify-center p-6">

    <div class="max-w-md w-full rounded-2xl overflow-hidden form-card">
        <!-- Header -->
        <div class="bg-gray-100 p-6 text-center">
            <h1 class="text-2xl font-semibold text-gray-800"><?php echo e(__('auth.welcome')); ?></h1>
            <p class="text-gray-500 mt-1"><?php echo e(__('auth.login_message')); ?></p>
        </div>

        <!-- Form -->
        <div class="p-8">
            <form action="<?php echo e(route('login')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Email -->
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                        <?php echo e(__('auth.email')); ?>

                    </label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </span>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?php echo e(old('email', Cookie::get('email'))); ?>"
                            placeholder="you@example.com"
                            required
                            class="input-field block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none transition duration-200">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password -->
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <label for="password" class="block text-sm font-medium text-gray-700"><?php echo e(__('auth.password')); ?></label>
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700"><?php echo e(__('auth.forgot_password')); ?></a>
                    </div>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                            <i class="fas fa-lock text-gray-400"></i>
                        </span>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value="<?php echo e(Cookie::get('password')); ?>"
                            placeholder="••••••••"
                            required
                            class="input-field block w-full pl-10 pr-10 py-3 border border-gray-300 rounded-lg focus:outline-none transition duration-200">
                        <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600"></i>
                        </button>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Remember & Submit -->
                <div class="flex items-center justify-between">
                    <label class="flex items-center">
                        <input type="checkbox" name="remember" id="remember" class="h-4 w-4 text-gray-600 border-gray-300 rounded">
                        <span class="ml-2 text-sm text-gray-700"><?php echo e(__('auth.remember_me')); ?></span>
                    </label>

                    <button
                        type="submit"
                        class="btn-primary text-white font-medium py-3 px-6 rounded-lg shadow-md transition duration-200 transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-1">
                        <?php echo e(__('auth.login_button')); ?>

                    </button>
                </div>
            </form>

            <div class="my-8 relative">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('password');
        togglePassword.addEventListener('click', () => {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            togglePassword.querySelector('i').classList.toggle('fa-eye');
            togglePassword.querySelector('i').classList.toggle('fa-eye-slash');
        });
    </script>
</body>

</html><?php /**PATH E:\work\New folder\DocuSyns\resources\views\user\login\signin.blade.php ENDPATH**/ ?>