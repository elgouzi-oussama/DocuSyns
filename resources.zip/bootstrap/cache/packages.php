<?php return array (
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'faisal50x/blade-ionicons' => 
  array (
    'aliases' => 
    array (
      'BladeIonicons' => 'Faisal50x\\BladeIonicons\\BladeIoniconsFacade',
    ),
    'providers' => 
    array (
      0 => 'Faisal50x\\BladeIonicons\\BladeIoniconsServiceProvider',
    ),
  ),
  'khatabwedaa/blade-css-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Khatabwedaa\\BladeCssIcons\\BladeCssIconsServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
);